//
//  ZJBluetooth.h
//  ZJBluetooth
//
//  Created by 智鉴科技 on 2018/11/21.
//  Copyright © 2018年 com.bjzhijian.www. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZJBluetoothManager.h"
#import "ZJAESEncrypt.h"
//! Project version number for ZJBluetooth.
FOUNDATION_EXPORT double ZJBluetoothVersionNumber;

//! Project version string for ZJBluetooth.
FOUNDATION_EXPORT const unsigned char ZJBluetoothVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZJBluetooth/PublicHeader.h>


