//
//  ZJAESEncrypt.h
//  zhijianSecondPhase
//
//  Created by 智鉴科技 on 2017/4/17.
//  Copyright © 2017年 com.bjzhijian.www. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZJAESEncrypt : NSObject
/**
 AES加密

 @param aesKey AESkey
 @param iv iv
 @param encrypt 密文
 @return 明文
 */
+ (NSString *_Nullable)encryptWithAESKEY:(nonnull NSString *)aesKey
                                      iv:(nonnull NSString *)iv
                                 encrypt:(nonnull NSString *)encrypt;

/**
 AES解密

 @param aesKey AESKEY
 @param iv iv
 @param decrypt 明文
 @return 密文
 */
+ (NSString *_Nullable)decryptWithAESKEY:(nonnull NSString *)aesKey
                                      iv:(nonnull NSString *)iv
                                 decrypt:(nonnull NSString *)decrypt;
@end
