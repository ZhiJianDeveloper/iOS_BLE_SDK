//
//  ZJBluetoothManager.h
//  BlueManager
//
//  Created by 智鉴科技 on 2017/12/6.
//  Copyright © 2017年 com.bjzhijian.www. All rights reserved.
//
#import <Foundation/Foundation.h>
@class ZJBluetoothManager;
typedef void (^ZJBluetoothManagerCompleteBlock)(NSInteger errorCode);
typedef void (^ZJBluetoothManagerEventBlock)(NSInteger number);
typedef void (^ZJBluetoothManagerDidReciveMsgCompleteBlock)(NSDictionary *data ,NSInteger errorCode);
@interface ZJBluetoothManager : NSObject
+ (instancetype)sharedManager;
/**
 断开蓝牙外设
 */
- (void)disconnectPeripheral;

/**
 初始化蓝牙SDK

 @param aesKey AES加密秘钥
 @param ivKey AES加密向量
 */
+ (void)initWithDefaultAESKey:(NSString *)aesKey ivKey:(NSString *)ivKey;

/**
 设置蓝牙扫描印章超时时长,默认为5秒

 @param second 超时时间
 */
+ (void)setDefaultScanningTimeoutSecond:(NSInteger)second;


/**
 根据印章显示屏获取印章mac地址

 @param message 显示屏内的二维码密文
 @return 印章mac地址
 */
+ (NSString *)getDisplayMacByQRCodeMessage:(NSString *)message;
 /**
 配置印章WiFi账号密码
 
 @param ssid wifi账号
 @param password wifi密码
 @param mac 印章mac地址
 @param completeBlock 回调
 */
- (void)requestConfigNetworkByWiFiSSID:(NSString *)ssid
                              password:(NSString *)password
                                   mac:(NSString *)mac
                         completeBlock:(ZJBluetoothManagerCompleteBlock)completeBlock;

/**
 使用印章

 @param time 服务器时间 格式为 yyyy-MM-dd HH:mm:ss
 @param useNumber 使用次数
 @param mac 印章mac地址
 @param thingId 事件ID
 @param completeBlock 回调
 @param eventBlock 印章被按压后的回调
 */
- (void)requestUseDeviceByTime:(NSString *)time
                     useNumber:(NSInteger )useNumber
                           mac:(NSString *)mac
                       thingId:(NSString *)thingId
                 completeBlock:(ZJBluetoothManagerCompleteBlock)completeBlock
                     eventBlock:(ZJBluetoothManagerEventBlock)eventBlock;

/**
 暂停印章

 @param time 服务器时间 格式为 yyyy-MM-dd HH:mm:ss
 @param mac 印章mac地址
 @param thingId 事件ID
 @param completeBlock 回调
 */
- (void)requestPauseDeviceByTime:(NSString *)time
                             mac:(NSString *)mac
                         thingId:(NSString *)thingId
                   completeBlock:(ZJBluetoothManagerCompleteBlock)completeBlock;
/**
 重新开启印章
 
 @param time 服务器时间 格式为 yyyy-MM-dd HH:mm:ss
 @param mac 印章mac地址
 @param thingId 事件ID
 @param completeBlock 回调
 */
- (void)requestRestartDeviceByTime:(NSString *)time
                             mac:(NSString *)mac
                         thingId:(NSString *)thingId
                   completeBlock:(ZJBluetoothManagerCompleteBlock)completeBlock;

/**
 停止用章

 @param time 服务器时间 格式为 yyyy-MM-dd HH:mm:ss
 @param mac 印章mac地址
 @param thingId 事件ID
 @param completeBlock 回调
 */
- (void)requestStopDeviceByTime:(NSString *)time
                            mac:(NSString *)mac
                        thingId:(NSString *)thingId
                  completeBlock:(ZJBluetoothManagerCompleteBlock)completeBlock;

/**
 维护印章

 @param time 服务器时间 格式为 yyyy-MM-dd HH:mm:ss
 @param mac 印章mac地址
 @param thingId 事件ID
 @param completeBlock 回调
 */
- (void)requestRepairDeviceByTime:(NSString *)time
                              mac:(NSString *)mac
                          thingId:(NSString *)thingId
                    completeBlock:(ZJBluetoothManagerCompleteBlock)completeBlock;

/**
 获取印章暂存用章记录

 @param time 服务器时间 格式为 yyyy-MM-dd HH:mm:ss
 @param mac 印章mac地址
 @param completeBlock 回调
 */
- (void)requestGetDeviceHistoryByTime:(NSString *)time
                                  mac:(NSString *)mac
                        completeBlock:(ZJBluetoothManagerDidReciveMsgCompleteBlock)completeBlock;

/**
 删除最新一条印章缓存记录

 @param time 服务器时间 格式为 yyyy-MM-dd HH:mm:ss
 @param mac 印章mac地址
 @param completeBlock 回调
 */
- (void)requestDeleteDeviceDataByTime:(NSString *)time
                                  mac:(NSString *)mac
                        completeBlock:(ZJBluetoothManagerCompleteBlock)completeBlock;

/**
 获取印章电量信息

 @param time 服务器时间
 @param mac 印章mac地址
 @param completeBlock 回调
 */
- (void)requestGetDeviceMsgByTime:(NSString *)time
                              mac:(NSString *)mac
                    completeBlock:(ZJBluetoothManagerDidReciveMsgCompleteBlock)completeBlock;

/**
 修改印章名称

 @param name 印章名称 要求仅支持数字中文英文字符
 @param time 服务器时间 格式为 yyyy-MM-dd HH:mm:ss
 @param mac 印章mac地址
 @param completeBlock 回调
 */
- (void)requestModifyDeviceByName:(NSString *)name
                             time:(NSString *)time
                                mac:(NSString *)mac
                            thingId:(NSString *)thingId
                      completeBlock:(ZJBluetoothManagerCompleteBlock)completeBlock;

@end


/*
 
 错误代码
 code    描述
 0    成功
 1    当前印章未处于使用印章状态
 2    缺少相关参数
 3    配网失败
 12   印章正在维护或者使用,请稍候重试
 13   事件存储已满
 871001    SDK AES秘钥未被初始化 或 秘钥长度不合法
 871003    缺少相应请求参数
 871004    mac地址为空
 871005    wifi密码过长
 871006    蓝牙搜索指定mac地址的印章超时
 871007    使用次数小于1或者大于20000次
 871008    印章名称过长或不合法
 871009    未开启蓝牙
 871010    事件ID不能为空,最大长度16 仅支持中文英文数字
 871002   日期参数格式错误
 */
