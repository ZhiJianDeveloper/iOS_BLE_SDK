//
//  ViewController.swift
//  ZJBluetoothSwiftDemo
//
//  Created by 智鉴科技 on 2018/11/21.
//  Copyright © 2018年 com.bjzhijian.www. All rights reserved.
//

import UIKit
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        ZJBluetoothManager.initWithDefaultAESKey("1234567890123456", ivKey: "1234567890123456")
        ZJBluetoothManager.shared()?.requestConfigNetwork(byWiFiSSID: "ziroom504", password: "4001001234", mac: "84-0D-8E-39-23-26", complete: { (errorCode) in
          print("错误代码=\(errorCode)")
        })
    }


}

